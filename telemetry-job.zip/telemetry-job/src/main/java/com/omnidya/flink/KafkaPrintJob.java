package com.omnidya.flink;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.omnidya.flink.model.EnrichedTelemetryEvent;
import com.omnidya.flink.model.TelemetryEvent;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema;
import org.apache.flink.connector.kafka.sink.KafkaSink;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.api.common.functions.MapFunction;

/**
 * 🚀 LIVE LOCATION SERVICE - Flink Job
 *
 * FLOW:
 * 1. Read JSON from Kafka (telemetry.raw)
 * 2. Parse to TelemetryEvent
 * 3. Key by device_uuid
 * 4. Track location history per device (using state)
 * 5. Enrich events with previous + recent locations
 * 6. Write to Kafka (telemetry.processed)
 */
public class KafkaPrintJob {

    public static void main(String[] args) throws Exception {
        // 🏗️ Step 1: Create Flink execution environment
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // 📥 Step 2: Configure Kafka SOURCE (telemetry.raw)
        KafkaSource<String> source =
                KafkaSource.<String>builder()
                .setBootstrapServers("kafka:9094")
                .setTopics("telemetry.raw")
                .setGroupId("flink-telemetry")
                .setValueOnlyDeserializer(new SimpleStringSchema())
                .build();

        // 📤 Step 3: Configure Kafka SINK (telemetry.processed)
        KafkaSink<String> sink = KafkaSink.<String>builder()
                .setBootstrapServers("kafka:9094")
                .setRecordSerializer(KafkaRecordSerializationSchema.builder()
                        .setTopic("telemetry.processed")
                        .setValueSerializationSchema(new SimpleStringSchema())
                        .build())
                .build();

        // 🔄 Step 4: Build the data pipeline
        DataStream<String> rawStream = env.fromSource(
                source,
                WatermarkStrategy.noWatermarks(),
                "kafka-source");

        // 🎯 Step 5: Parse JSON → TelemetryEvent
        DataStream<TelemetryEvent> telemetryStream = rawStream
                .map(new JsonToTelemetryMapper())
                .name("Parse JSON to TelemetryEvent")
                .filter(event -> event != null)  // 🔧 Filter out invalid records
                .name("Filter Invalid Records");

        // 🔑 Step 6: Key by device_uuid and track location history
        DataStream<EnrichedTelemetryEvent> enrichedStream = telemetryStream
                .keyBy(event -> event.deviceUuid)  // Group by device_uuid
                .process(new LocationTrackingFunction())  // Track locations with state
                .name("Track Location History");

        // 📝 Step 7: Convert EnrichedTelemetryEvent → JSON
        DataStream<String> outputStream = enrichedStream
                .map(new EnrichedTelemetryToJsonMapper())
                .name("Serialize to JSON");

        // 📤 Step 8: Write to Kafka
        outputStream.sinkTo(sink);

        // 🚀 Execute the job
        env.execute("live-location-tracking-job");
    }

    /**
     * 🔧 Helper: JSON String → TelemetryEvent
     * Returns null for invalid records (to be filtered out later)
     */
    public static class JsonToTelemetryMapper implements MapFunction<String, TelemetryEvent> {
        private transient ObjectMapper objectMapper;

        @Override
        public TelemetryEvent map(String json) throws Exception {
            if (objectMapper == null) {
                objectMapper = new ObjectMapper();
                // 🔧 Configure to be lenient with unknown fields
                objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            }

            try {
                // Skip null or empty messages
                if (json == null || json.trim().isEmpty()) {
                    System.err.println("⚠️ SKIPPING: Empty message");
                    return null;
                }

                // 🐛 Debug: Print first 200 chars of the message
                System.out.println("📥 RAW MESSAGE: " +
                    (json.length() > 200 ? json.substring(0, 200) + "..." : json));

                // 🔧 FIX: Remove surrounding quotes if double-encoded
                String cleanedJson = json;
                if (json.startsWith("\"") && json.endsWith("\"")) {
                    cleanedJson = json.substring(1, json.length() - 1)
                        .replace("\\\"", "\"")  // Unescape quotes
                        .replace("\\\\", "\\"); // Unescape backslashes
                    System.out.println("🔧 UNWRAPPED: " +
                        (cleanedJson.length() > 200 ? cleanedJson.substring(0, 200) + "..." : cleanedJson));
                }

                return objectMapper.readValue(cleanedJson, TelemetryEvent.class);
            } catch (Exception e) {
                // 🐛 Debug: Print the full problematic message
                System.err.println("❌ FAILED TO PARSE JSON (SKIPPING RECORD):");
                System.err.println("Message length: " + json.length());
                System.err.println("First 500 chars: " +
                    (json.length() > 500 ? json.substring(0, 500) : json));
                System.err.println("Error: " + e.getMessage());

                // Return null instead of throwing - will be filtered out
                return null;
            }
        }
    }

    /**
     * 🔧 Helper: EnrichedTelemetryEvent → JSON String
     */
    public static class EnrichedTelemetryToJsonMapper implements MapFunction<EnrichedTelemetryEvent, String> {
        private transient ObjectMapper objectMapper;

        @Override
        public String map(EnrichedTelemetryEvent event) throws Exception {
            if (objectMapper == null) {
                objectMapper = new ObjectMapper();
                // 🔧 Configure to be lenient
                objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            }
            return objectMapper.writeValueAsString(event);
        }
    }
}
