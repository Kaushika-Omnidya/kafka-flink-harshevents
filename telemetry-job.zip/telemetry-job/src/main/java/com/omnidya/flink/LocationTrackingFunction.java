package com.omnidya.flink;

import com.omnidya.flink.model.EnrichedTelemetryEvent;
import com.omnidya.flink.model.TelemetryEvent;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;

/**
 * 🎯 This function tracks location history for each device
 *
 * HOW IT WORKS (for beginners):
 *
 * 1. Flink automatically groups events by device_uuid (we set this up in the main job)
 * 2. For EACH device, Flink maintains separate state (like a mini-database per device)
 * 3. We store two locations: 'previous' and 'recent'
 * 4. When a new event arrives:
 *    - previous_location = what was recent
 *    - recent_location = current event's location
 * 5. We output the enriched event with both locations
 */
public class LocationTrackingFunction extends KeyedProcessFunction<String, TelemetryEvent, EnrichedTelemetryEvent> {

    // 📦 STATE: Flink stores this data per device_uuid
    // Think of it as: Map<device_uuid, GeoLocation>
    private transient ValueState<TelemetryEvent.GeoLocation> previousLocationState;
    private transient ValueState<TelemetryEvent.GeoLocation> recentLocationState;

    /**
     * 🚀 This is called ONCE when Flink starts the job
     * We initialize our state variables here
     */
    @Override
    public void open(Configuration parameters) throws Exception {
        // Define state for 'previous_location' - stored per device
        ValueStateDescriptor<TelemetryEvent.GeoLocation> previousDescriptor =
                new ValueStateDescriptor<>(
                        "previous-location",              // name of the state
                        TelemetryEvent.GeoLocation.class  // type of data stored
                );
        previousLocationState = getRuntimeContext().getState(previousDescriptor);

        // Define state for 'recent_location' - stored per device
        ValueStateDescriptor<TelemetryEvent.GeoLocation> recentDescriptor =
                new ValueStateDescriptor<>(
                        "recent-location",
                        TelemetryEvent.GeoLocation.class
                );
        recentLocationState = getRuntimeContext().getState(recentDescriptor);
    }

    /**
     * 🎬 This is called for EVERY event that comes in
     *
     * @param event The telemetry event from Kafka
     * @param ctx Context (we don't use this now, but it's available for timers, etc.)
     * @param out Collector to emit output events
     */
    @Override
    public void processElement(
            TelemetryEvent event,
            Context ctx,
            Collector<EnrichedTelemetryEvent> out) throws Exception {

        // 📖 READ current state for THIS device
        // If this is the first event for this device, these will be null
        TelemetryEvent.GeoLocation previousLocation = previousLocationState.value();
        TelemetryEvent.GeoLocation recentLocation = recentLocationState.value();

        // 🔄 UPDATE STATE: Shift locations
        // What was 'recent' becomes 'previous'
        // Current location becomes 'recent'
        if (event.location != null) {
            // Update previous = old recent
            previousLocationState.update(recentLocation); // This might be null for first event

            // Update recent = current event's location
            recentLocationState.update(event.location);
        }

        // 📦 CREATE enriched event with location history
        EnrichedTelemetryEvent enrichedEvent = EnrichedTelemetryEvent.fromTelemetryEvent(
                event,
                previousLocation,  // might be null for first 1-2 events
                event.location     // current location becomes recent_location
        );

        // 📤 EMIT the enriched event downstream (to Kafka sink)
        out.collect(enrichedEvent);
    }
}
