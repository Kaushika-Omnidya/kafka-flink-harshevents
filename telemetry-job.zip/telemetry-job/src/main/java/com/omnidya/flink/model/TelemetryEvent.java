package com.omnidya.flink.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;

/**
 * Represents raw telemetry data received from Kafka
 */
public class TelemetryEvent implements Serializable {

    @JsonProperty("device_uuid")
    public String deviceUuid;

    @JsonProperty("mqtt_sent_at_ms")
    public Long mqttSentAtMs;

    public Long timestamp;

    @JsonProperty("fix_quality")
    public String fixQuality;

    @JsonProperty("temp_C")
    public Double tempC;

    @JsonProperty("accel_x")
    public Double accelX;

    @JsonProperty("accel_y")
    public Double accelY;

    @JsonProperty("accel_z")
    public Double accelZ;

    @JsonProperty("gyro_x")
    public Double gyroX;

    @JsonProperty("gyro_y")
    public Double gyroY;

    @JsonProperty("gyro_z")
    public Double gyroZ;

    @JsonProperty("cpu_temp")
    public Integer cpuTemp;

    @JsonProperty("soc_temp")
    public Integer socTemp;

    @JsonProperty("main_board_temp")
    public Double mainBoardTemp;

    @JsonProperty("sim_iccid")
    public String simIccid;

    @JsonProperty("sim_imsi")
    public String simImsi;

    @JsonProperty("signal_strength_percent")
    public Integer signalStrengthPercent;

    @JsonProperty("imu_is_stopped")
    public Boolean imuIsStopped;

    @JsonProperty("dashcam_power_source")
    public String dashcamPowerSource;

    @JsonProperty("battery_capacity")
    public Integer batteryCapacity;

    @JsonProperty("lat_dir")
    public String latDir;

    @JsonProperty("lon_dir")
    public String lonDir;

    @JsonProperty("location_changed")
    public Boolean locationChanged;

    @JsonProperty("speed_kph")
    public Double speedKph;

    @JsonProperty("speed_mph")
    public Double speedMph;

    public Boolean ontrip;

    public GeoLocation location;

    @JsonProperty("vehicle_id")
    public String vehicleId;

    @JsonProperty("account_id")
    public String accountId;

    public String[] violations;

    // Default constructor for Jackson
    public TelemetryEvent() {}

    public static class GeoLocation implements Serializable {
        public String type;
        public double[] coordinates; // [longitude, latitude]

        public GeoLocation() {}

        public GeoLocation(String type, double[] coordinates) {
            this.type = type;
            this.coordinates = coordinates;
        }
    }
}
