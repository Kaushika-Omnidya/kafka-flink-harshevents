package com.omnidya.flink.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;

/**
 * Enriched telemetry event with location history (previous and recent locations)
 */
public class EnrichedTelemetryEvent implements Serializable {

    // All original fields from TelemetryEvent
    @JsonProperty("device_uuid")
    public String deviceUuid;

    @JsonProperty("mqtt_sent_at_ms")
    public Long mqttSentAtMs;

    public Long timestamp;

    @JsonProperty("fix_quality")
    public String fixQuality;

    @JsonProperty("temp_C")
    public Double tempC;

    @JsonProperty("accel_x")
    public Double accelX;

    @JsonProperty("accel_y")
    public Double accelY;

    @JsonProperty("accel_z")
    public Double accelZ;

    @JsonProperty("gyro_x")
    public Double gyroX;

    @JsonProperty("gyro_y")
    public Double gyroY;

    @JsonProperty("gyro_z")
    public Double gyroZ;

    @JsonProperty("cpu_temp")
    public Integer cpuTemp;

    @JsonProperty("soc_temp")
    public Integer socTemp;

    @JsonProperty("main_board_temp")
    public Double mainBoardTemp;

    @JsonProperty("sim_iccid")
    public String simIccid;

    @JsonProperty("sim_imsi")
    public String simImsi;

    @JsonProperty("signal_strength_percent")
    public Integer signalStrengthPercent;

    @JsonProperty("imu_is_stopped")
    public Boolean imuIsStopped;

    @JsonProperty("dashcam_power_source")
    public String dashcamPowerSource;

    @JsonProperty("battery_capacity")
    public Integer batteryCapacity;

    @JsonProperty("lat_dir")
    public String latDir;

    @JsonProperty("lon_dir")
    public String lonDir;

    @JsonProperty("location_changed")
    public Boolean locationChanged;

    @JsonProperty("speed_kph")
    public Double speedKph;

    @JsonProperty("speed_mph")
    public Double speedMph;

    public Boolean ontrip;

    @JsonProperty("vehicle_id")
    public String vehicleId;

    @JsonProperty("account_id")
    public String accountId;

    public String[] violations;

    // NEW FIELDS for live-location service
    @JsonProperty("recent_location")
    public TelemetryEvent.GeoLocation recentLocation;

    @JsonProperty("previous_location")
    public TelemetryEvent.GeoLocation previousLocation;

    // Default constructor
    public EnrichedTelemetryEvent() {}

    /**
     * Create enriched event from original telemetry event
     */
    public static EnrichedTelemetryEvent fromTelemetryEvent(
            TelemetryEvent event,
            TelemetryEvent.GeoLocation previousLocation,
            TelemetryEvent.GeoLocation recentLocation) {

        EnrichedTelemetryEvent enriched = new EnrichedTelemetryEvent();

        // Copy all original fields
        enriched.deviceUuid = event.deviceUuid;
        enriched.mqttSentAtMs = event.mqttSentAtMs;
        enriched.timestamp = event.timestamp;
        enriched.fixQuality = event.fixQuality;
        enriched.tempC = event.tempC;
        enriched.accelX = event.accelX;
        enriched.accelY = event.accelY;
        enriched.accelZ = event.accelZ;
        enriched.gyroX = event.gyroX;
        enriched.gyroY = event.gyroY;
        enriched.gyroZ = event.gyroZ;
        enriched.cpuTemp = event.cpuTemp;
        enriched.socTemp = event.socTemp;
        enriched.mainBoardTemp = event.mainBoardTemp;
        enriched.simIccid = event.simIccid;
        enriched.simImsi = event.simImsi;
        enriched.signalStrengthPercent = event.signalStrengthPercent;
        enriched.imuIsStopped = event.imuIsStopped;
        enriched.dashcamPowerSource = event.dashcamPowerSource;
        enriched.batteryCapacity = event.batteryCapacity;
        enriched.latDir = event.latDir;
        enriched.lonDir = event.lonDir;
        enriched.locationChanged = event.locationChanged;
        enriched.speedKph = event.speedKph;
        enriched.speedMph = event.speedMph;
        enriched.ontrip = event.ontrip;
        enriched.vehicleId = event.vehicleId;
        enriched.accountId = event.accountId;
        enriched.violations = event.violations;

        // Add location history
        enriched.recentLocation = recentLocation;
        enriched.previousLocation = previousLocation;

        return enriched;
    }
}
